﻿using QuickGraph;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace CombVV
{
    public class StandardsMethodsGraph
    {
        public Dictionary<int, int> MethodCost { get; private set; }

        public bool HasWeights { get; private set; }

        public AdjacencyGraph<int, Edge<int>> Graph { get; private set; }

        public HashSet<int> Standards { get; private set; }

        public HashSet<int> Methods { get; private set; }

        public Dictionary<Edge<int>, int> EdgeCost { get; private set; }

        public StandardsMethodsGraph(
            List<int> standards, List<int> methods, List<Edge<int>> edges, 
            Dictionary<Edge<int>, int> edgeCost = null, Dictionary<int, int> methodCost = null)
        {
            Standards = new HashSet<int>(standards);
            Methods = new HashSet<int>(methods);
            if (edgeCost != null)
                EdgeCost = edgeCost;
            else EdgeCost = new Dictionary<Edge<int>, int>();
            if (methodCost != null)
            {
                MethodCost = methodCost;
                HasWeights = true;
            }

            List<int> vertices = standards.Union(methods).ToList();
            Graph = new AdjacencyGraph<int, Edge<int>>();

            foreach (var vertex in vertices)
            {
                Graph.AddVertex(vertex);
            }
            foreach (var edge in edges)
            {
                Graph.AddEdge(edge);
                Graph.AddEdge(new Edge<int>(edge.Target, edge.Source));
            }
        }

        public HashSet<int> BruteForce()
        {
            return BruteForce(0, new bool[Methods.Count], Methods.ToArray());
        }

        public HashSet<int> BruteForce(int i, bool[] selected, int[] myMethods)
        {
            //if (i < 2) Console.WriteLine("STOP in i = {0}", i);
            if (i == myMethods.Length)
            {
                HashSet<int> ret = new HashSet<int>();
                HashSet<int> st = new HashSet<int>();
                for (int j = 0; j < Methods.Count; j++)
                {
                    if (selected[j] == true)
                    {
                        ret.Add(myMethods[j]);
                        st = new HashSet<int>(
                            Graph.OutEdges(myMethods[j]).Select(e => e.Target).Union(st));
                    }
                }
                if (st.Count == Standards.Count) return ret;
                else return new HashSet<int>(Enumerable.Range(0, myMethods.Length + 1));
            }
            else
            {
                selected[i] = false;
                var res1 = BruteForce(i + 1, selected, myMethods);

                selected[i] = true;
                var res2 = BruteForce(i + 1, selected, myMethods);

                if (res1.Count < res2.Count) return res1;
                else return res2;
            }
        }

        public HashSet<int> SetCoverFPT(bool use_preprocessing)
        {
            return SetCoverFPT(current_standards: Standards, current_methods: Methods, use_preprocessing: use_preprocessing);
        }

        private HashSet<int> SetCoverFPT(HashSet<int> current_standards, HashSet<int> current_methods, bool use_preprocessing)
        {
            HashSet<int> M_star = new HashSet<int>(current_methods);
            int f_star = 1000000;

            if (current_standards.Count == 0)
                return new HashSet<int>();
            else
            {
                if (use_preprocessing)
                {
                    current_methods = RemoveSubsets(current_methods, current_standards);
                    //if (current_methods.Count < f_star)
                    //{
                    //    f_star = current_methods.Count;
                    //    M_star = new HashSet<int>(current_methods);
                    //}
                }
                // En vez de First(), seleccionar un estandar entre los estandares cubiertos por
                // el metodo que mas estandares cubra. Seleccionar aquel al que menos metodos cubran.
                var s = current_standards.First();
                var S_t = new HashSet<int>(current_standards.Except(new[] { s }));

                foreach (var m in Neighbors(s, current_methods))
                {
                    var M_prime = new HashSet<int>(new[] { m });
                    S_t = new HashSet<int>(S_t.Except(Neighbors(m, current_standards)));
                    var M_t = new HashSet<int>(current_methods.Except(R(m, current_standards, current_methods)));

                    var covered_by_one = AnyCoveredByOne(S_t, M_t);
                    while (covered_by_one != -1)
                    {
                        var m_prime = Neighbors(covered_by_one, current_methods).Intersect(M_t).Single();
                        S_t = new HashSet<int>(S_t.Except(Neighbors(m_prime, current_standards)));
                        M_t = new HashSet<int>(M_t.Except(new[] { m_prime }));
                        M_prime = new HashSet<int>(M_prime.Union(new[] { m_prime }));
                        covered_by_one = AnyCoveredByOne(S_t, M_t);
                    }

                    var M_prime_star = SetCoverFPT(S_t, M_t, use_preprocessing);
                    if (M_prime_star != null && M_prime_star.Count + M_prime.Count < f_star)
                    {
                        f_star = M_prime_star.Count + M_prime.Count;
                        M_star = new HashSet<int>(M_prime_star.Union(M_prime));
                    }
                    S_t = new HashSet<int>(current_standards.Except(new[] { s }));
                }
            }

            if (f_star == 1000000) return null;
            return M_star;
        }

        public List<HashSet<int>> SetCoverFPT_AllOptima(bool use_preprocessing)
        {
            return SetCoverFPT_AllOptima(current_standards: Standards, current_methods: Methods, use_preprocessing: use_preprocessing);
        }

        private List<HashSet<int>> SetCoverFPT_AllOptima(HashSet<int> current_standards, HashSet<int> current_methods, bool use_preprocessing)
        {
            List<HashSet<int>> M_star = new List<HashSet<int>> { new HashSet<int>(current_methods) };
            int f_star = 1000000;

            if (current_standards.Count == 0)
                return new List<HashSet<int>> { new HashSet<int>() };
            else
            {
                if (use_preprocessing)
                {
                    current_methods = RemoveSubsets(current_methods, current_standards);
                    // Not considers weights of methods
                    //if (current_methods.Count < f_star)
                    //{
                    //    f_star = current_methods.Count;
                    //    M_star = new HashSet<int>(current_methods);
                    //}
                }
                // En vez de First(), seleccionar un estandar entre los estandares cubiertos por
                // el metodo que mas estandares cubra. Seleccionar aquel al que menos metodos cubran.
                var s = current_standards.First();
                var S_t = new HashSet<int>(current_standards.Except(new[] { s }));

                foreach (var m in Neighbors(s, current_methods))
                {
                    var M_prime = new HashSet<int>(new[] { m });
                    S_t = new HashSet<int>(S_t.Except(Neighbors(m, current_standards)));
                    var M_t = new HashSet<int>(current_methods.Except(R(m, current_standards, current_methods)));

                    var covered_by_one = AnyCoveredByOne(S_t, M_t);
                    while (covered_by_one != -1)
                    {
                        var m_prime = Neighbors(covered_by_one, current_methods).Intersect(M_t).Single();
                        S_t = new HashSet<int>(S_t.Except(Neighbors(m_prime, current_standards)));
                        M_t = new HashSet<int>(M_t.Except(new[] { m_prime }));
                        M_prime = new HashSet<int>(M_prime.Union(new[] { m_prime }));
                        covered_by_one = AnyCoveredByOne(S_t, M_t);
                    }

                    var M_prime_star = SetCoverFPT_AllOptima(S_t, M_t, use_preprocessing);
                    if (M_prime_star != null && CostOfSolution(M_prime_star[0]) + CostOfSolution(M_prime) < f_star)
                    {
                        f_star = CostOfSolution(M_prime_star[0]) + CostOfSolution(M_prime);
                        M_star = new List<HashSet<int>>();
                        foreach (var sol in M_prime_star)
                        {
                            var new_sol = new HashSet<int>(sol.Union(M_prime));
                            if (!(M_star.Contains(new_sol, new HastSetIntComparer())))
                            {
                                M_star.Add(new_sol);
                            }
                        }
                    }
                    else if (M_prime_star != null && CostOfSolution(M_prime_star[0]) + CostOfSolution(M_prime) == f_star)
                    {
                        foreach(var sol in M_prime_star)
                        {
                            var new_sol = new HashSet<int>(sol.Union(M_prime));
                            if (!(M_star.Contains(new_sol, new HastSetIntComparer())))
                            {
                                M_star.Add(new_sol);
                            }
                        }
                    }
                    S_t = new HashSet<int>(current_standards.Except(new[] { s }));
                }
            }

            if (f_star == 1000000) return null;
            return M_star;
        }

        private HashSet<int> RemoveSubsets(HashSet<int> current_methods, HashSet<int> current_standards)
        {
            var loc_methods = current_methods.ToList();
            var loc_standar = current_standards.ToList();
            bool[,] adj_matrix = new bool[loc_methods.Count, loc_standar.Count];

            for (int i = 0; i < loc_methods.Count; i++)
            {
                for (int j = 0; j < loc_standar.Count; j++)
                {
                    if (Graph.OutEdges(loc_methods[i]).Select(e => e.Target).Contains(loc_standar[j]))
                        adj_matrix[i, j] = true;
                }
            }

            bool[] to_remove = new bool[loc_methods.Count];
            for (int i = 0; i < loc_methods.Count; i++)
            {
                bool is_subrow = false;
                for (int j = 0; j < loc_methods.Count; j++)
                {
                    if (to_remove[j] || i == j) continue;
                    if (IsSubrow(adj_matrix, i, j))
                    {
                        is_subrow = true;
                        break;
                    }
                }
                if (is_subrow) to_remove[i] = true;
            }

            var ret = new HashSet<int>();
            for (int i = 0; i < loc_methods.Count; i++)
            {
                if (!to_remove[i]) ret.Add(loc_methods[i]);
            }
            return ret;
        }

        public bool IsSubrow(bool[,] matrix, int row1, int row2)
        {
            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                if (matrix[row1, j] && !matrix[row2, j]) return false;
            }
            return true;
        }

        public HashSet<int> Neighbors(int vertex, HashSet<int> currect_elements)
        {
            return new HashSet<int>(Graph.OutEdges(vertex).Select(e => e.Target).Intersect(currect_elements));
        }
        
        private IEnumerable<int> R(int m, HashSet<int> current_standards, HashSet<int> current_methods)
        {
            foreach (var method in current_methods)
            {
                if(Neighbors(method, current_standards).IsSubsetOf(Neighbors(m, current_standards)))
                {
                    yield return method;
                }
            }
        }

        /// <summary>
        /// Returns the first founded standard covered by one method
        /// </summary>
        /// <param name="M_t"></param>
        /// <returns>Returns -1 if there is no covered by one</returns>
        private int AnyCoveredByOne(HashSet<int> S_t, HashSet<int> M_t)
        {
            foreach (var standard in S_t)
            {
                if (Neighbors(standard, M_t).Count == 1) return standard;
            }
            return -1;
        }

        private int CostOfSolution(HashSet<int> solution)
        {
            if (!HasWeights)
            {
                return solution.Count;
            }
            else
            {
                int result_cost = 0;
                foreach (var m in solution)
                {
                    result_cost += MethodCost[m];
                }
                return result_cost;
            }
        }

        public void WriteToCSV(string filename)
        {
            StreamWriter sw = new StreamWriter(filename);

            sw.WriteLine("#");

            foreach (var vertex in Methods)
            {
                string line = "";
                var neighbors = Graph.OutEdges(vertex).Select(x => x.Target).ToList();

                foreach (var item in Standards)
                {
                    if (neighbors.Contains(item)) line += "1,";
                    else line += "0,";
                }
                sw.WriteLine(line.Substring(0, line.Length - 1));
            }

            sw.Close();
        }
    }

    public class HastSetIntComparer : IEqualityComparer<HashSet<int>>
    {
        public bool Equals(HashSet<int> x, HashSet<int> y)
        {
            return x.SetEquals(y);
        }

        public int GetHashCode(HashSet<int> obj)
        {
            return obj.GetHashCode();
        }
    }
}
