﻿using System;
using System.Collections.Generic;
using System.Linq;
using QuickGraph;

namespace CombVV
{
    class MyGraphGenerator
    {
        //instance variables
        int charactNumber;
        int methodsNumber;
        double prob;
        public static Random r = new Random();

        public MyGraphGenerator(int charactNumber = 8, int methodsNumber = 20, double prob = 0.5)
        {
            this.charactNumber = charactNumber;
            this.methodsNumber = methodsNumber;
            this.prob = prob;
        }

        public AdjacencyGraph<int, Edge<int>> GenerateAdjacencyGraph()
        {
            AdjacencyGraph<int, Edge<int>> graph = new AdjacencyGraph<int, Edge<int>>();

            foreach (var index in Enumerable.Range(0, charactNumber + methodsNumber))
            {
                graph.AddVertex(index);
            }

            foreach (var vertex1 in Enumerable.Range(0, charactNumber))
            {
                foreach (var vertex2 in Enumerable.Range(charactNumber, charactNumber + methodsNumber))
                {
                    if(r.NextDouble() < prob)
                    {
                        graph.AddEdge(new Edge<int>(vertex1, vertex2));
                        graph.AddEdge(new Edge<int>(vertex2, vertex1));
                    }
                }
            }

            return graph;
        }

        public StandardsMethodsGraph GenerateStandardsMethodsGraph()
        {
            List<int> standards = new List<int>();
            List<int> methods = new List<int>();
            List<Edge<int>> edges = new List<Edge<int>>();

            foreach (var item in Enumerable.Range(0, charactNumber))
            {
                standards.Add(item);
            }

            foreach (var item in Enumerable.Range(charactNumber, methodsNumber))
            {
                methods.Add(item);
            }

            foreach (var vertex1 in Enumerable.Range(0, charactNumber))
            {
                foreach (var vertex2 in Enumerable.Range(charactNumber, methodsNumber))
                {
                    if (r.NextDouble() < prob)
                    {
                        edges.Add(new Edge<int>(vertex1, vertex2));
                    }
                }
            }

            return new StandardsMethodsGraph(standards, methods, edges);
        }
    }
}
