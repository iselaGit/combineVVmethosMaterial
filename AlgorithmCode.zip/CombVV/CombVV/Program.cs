﻿using System;
using System.Collections.Generic;

namespace CombVV
{
    class Program
    {
        static int[] method_numbers = new[] { 20, 50, 100, 200, 500, 1000};
        static double[] probab_values = new[] { 0.01, 0.02, 0.05, 0.1, 0.2, 0.5 };
        static int st_number = 8;

        static void Main()
        {
            //GenerateInstances();
            //ProcessAllInstances();
            ProcessOneInstance("test.csv");

            //ProcessOneInstance("Instancias5_ERPeSMP.csv");
            //ProcessOneInstance("Instancias5_TaoV.csv");
            //ProcessOneInstance("Instancias5_VIeVT.csv");

            //ProcessOneInstance("Instancias4e5_ERPeSMP.csv");
            //ProcessOneInstance("Instancias4e5_TaoV.csv");
            //ProcessOneInstance("Instancias4e5_VT.csv");
            //ProcessOneInstance("Instancias4e5_VI.csv");


            Console.ReadLine();
        }

        private static void ProcessAllInstances()
        {
            foreach (var methods in method_numbers)
            {
                foreach (var probab in probab_values)
                {
                    ProcessOneInstance(InstanceName(methods, probab));
                    //Console.ReadLine();
                }
            }
        }

        private static void ProcessOneInstance(string instance_name)
        {
            CSVGraphReader CSVGraph = new CSVGraphReader();
            var smGraph = CSVGraph.GraphReader(instance_name, st_number, has_weights: true);
            //HashSet<int> solution = null;
            List<HashSet<int>> solution = null;

            var tick = Environment.TickCount;
            for (int i = 0; i < 1; i++)
            {
                solution = smGraph.SetCoverFPT_AllOptima(use_preprocessing: false);
                //solution = smGraph.SetCoverFPT(use_preprocessing: true);
                //solution = smGraph.BruteForce();
            }
            var exec_time = ((double)Environment.TickCount - tick) / (100 * 1000);
            //PrintGraph(smGraph);

            Console.WriteLine("Execution time of instance {0}: {1}", instance_name, exec_time);
            Console.WriteLine("  Solution of instance {0}: {1}",
                instance_name, solution == null ? "No solution" : solution.Count.ToString());
            foreach (var sol in solution)
            {
                Console.WriteLine(PrintSolution(sol));
            }
            //Console.WriteLine(PrintSolution(solution));
            Console.WriteLine();
        }

        private static void GenerateInstances()
        {
            foreach (var methods in method_numbers)
            {
                foreach (var probab in probab_values)
                {
                    var gg = new MyGraphGenerator(8, methods, probab);
                    var graph = gg.GenerateStandardsMethodsGraph();
                    graph.WriteToCSV(InstanceName(methods, probab));
                }
            }
            Console.WriteLine("Generation ended.");
        }

        private static string InstanceName(int methods, double probab)
        {
            return "instance_" + methods.ToString() + "_" + (probab * 100).ToString() + ".txt";
        }

        private static string PrintSolution(HashSet<int> solution)
        {
            if (solution == null) return "  Null solution";
            string res = "  Chosen methods: ";
            foreach (var method in solution)
            {
                res += method + ", ";
            }
            return res;
        }

        private static void PrintGraph(StandardsMethodsGraph smGraph)
        {
            Console.WriteLine(smGraph.Graph.EdgeCount / 2);
            foreach (var edge in smGraph.Graph.Edges)
            {
                if (edge.Source < edge.Target)
                    Console.WriteLine("An edge betweeen {0} and {1}", edge.Source, edge.Target);
            }
        }
    }
}
