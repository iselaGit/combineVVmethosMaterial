﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using QuickGraph;

namespace CombVV
{
    public class CSVGraphReader
    {
        public StandardsMethodsGraph GraphReader(string file, int standard_columns=9, bool has_weights=true)
        {
            var filestream = new StreamReader(file);

            var standards = new List<int>();
            var methods = new List<int>();
            List<Edge<int>> edges = new List<Edge<int>>();
            Dictionary<Edge<int>, int> edgeCost = new Dictionary<Edge<int>, int>();
            Dictionary<int, int> methodCost = new Dictionary<int, int>();
            
            for (int i = 0; i < standard_columns; i++)
            {
                standards.Add(25010 + i);
            }

            var line = filestream.ReadLine();
            while (line[0] == '#')
            {
                line = filestream.ReadLine();
            }

            int count = 0; 
            while (true)
            {
                methods.Add(++count);
                var element = line.Split(',');

                for (int i = 0; i < element.Length; i++)
                {
                    int var = int.Parse(element[i]);
                    if (has_weights && i == element.Length - 1)
                    {
                        methodCost[count] = var;
                    }
                    else if (var > 0)
                    {
                        var edge = new Edge<int>(count, 25010 + i);
                        edges.Add(edge);
                        edgeCost.Add(edge, var);
                    }
                }

                if (!filestream.EndOfStream) line = filestream.ReadLine();
                else break;
            }
            filestream.Close();

            return new StandardsMethodsGraph(standards, methods, edges, edgeCost, methodCost);
        }
    }
}
